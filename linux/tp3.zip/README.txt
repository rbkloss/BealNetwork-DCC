Para execu��o, rode primeiro o Servidor com:
  Servidor.exe porta
Ent�o para calcular um intervalo, rode o cliente da seguinte forma:
  Cliente.exe hostAddr port idCliente
Para consultar o status, do browser digite hostAddr:port

Caso o makefile padr�o n�o funcione, tente a c�pia.(Pode ser problam com o -std)